/* Used to offer the sidebar on/off feature */

function toggleNav() {
	var sidebar = document.getElementById("mySidebar");
	var main = document.getElementById("main");
	var header = document.querySelector(".pageheader");
	if (sidebar.style.width === "219px" || sidebar.style.width === "") {
		sidebar.style.width = "0";
		sidebar.style.paddingLeft = "0";
		main.style.marginLeft = "0";
		header.style.left = "50%";
		header.style.transform = "translate(-50%, 0)";
	} else {
		sidebar.style.width = "219px";
		sidebar.style.paddingLeft = "20px";
		main.style.marginLeft = "240px";
		header.style.left = "260px";
		header.style.transform = "none";
	}
}

/* Back scrolls 75 pixels when loading an anchor URL, to clear the header */

/*window.addEventListener('load', function() {
    if (window.location.hash) {
        setTimeout(() => {
            window.scrollBy(0, -75);
        }, 100);
    }
});*/

window.addEventListener('load', function() {
    if (window.location.hash) {
        // Skip if hash matches the pattern #[text]_text
        if (!window.location.hash.match(/^\#\[.*\]_.*/)) {
            setTimeout(() => {
                window.scrollBy(0, -75);
            }, 100);
        }
    }
});