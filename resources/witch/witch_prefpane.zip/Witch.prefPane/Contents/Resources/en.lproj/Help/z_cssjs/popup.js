document.addEventListener('DOMContentLoaded', () => {
    const thumbnails = document.querySelectorAll('.thumbnail');
    const popup = document.querySelector('.popup');
    const popupImage = popup.querySelector('img');

    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', (e) => {
            const fullImgSrc = thumbnail.getAttribute('data-full-img');
            if (fullImgSrc) {
                popupImage.onload = () => {
                    const naturalWidth = popupImage.naturalWidth / 2;
                    const naturalHeight = popupImage.naturalHeight / 2;

                    popupImage.style.maxWidth = '60vw';
                    popupImage.style.maxHeight = '80vh';
                    popupImage.style.width = `${naturalWidth}px`;
                    popupImage.style.height = 'auto'; // Maintain aspect ratio

                    popup.style.display = 'flex';
                    
                    const mouseX = e.clientX;
                    const mouseY = e.clientY;
                    const popupWidth = popup.offsetWidth;
                    const popupHeight = popup.offsetHeight;
                    const viewportWidth = window.innerWidth;
                    const viewportHeight = window.innerHeight;
                    let top = mouseY - 20;
                    let left = mouseX - 20;
                    if (mouseX + popupWidth > viewportWidth) {
                        left = viewportWidth - popupWidth - 10;
                    }
                    if (mouseY + popupHeight > viewportHeight) {
                        top = viewportHeight - popupHeight - 10;
                    }
                    popup.style.top = `${top}px`;
                    popup.style.left = `${left}px`;
                    e.stopPropagation();
                };

                popupImage.src = fullImgSrc;
            }
        });
    });

    document.addEventListener('click', () => {
        if (popup.style.display === 'flex') {
            closePopup();
        }
    });

    function closePopup() {
        popup.style.display = 'none';
        popupImage.src = '';
    }
});
